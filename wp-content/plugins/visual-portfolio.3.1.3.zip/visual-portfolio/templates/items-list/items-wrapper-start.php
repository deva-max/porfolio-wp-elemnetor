<?php
/**
 * Items wrapper start.
 *
 * @var $options
 * @var $style_options
 * @var $class
 *
 * @package visual-portfolio
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

?>

<div class="<?php echo esc_attr( $class ); ?>">
