<?php
/**
 * Wrapper end.
 *
 * @var $options
 * @var $style_options
 *
 * @package visual-portfolio
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

?>

</div>
