<?php

class Brizy_Admin_Fonts_Exception_DuplicateFont extends Exception
{

}