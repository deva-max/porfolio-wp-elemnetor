<?php


class Brizy_Editor_Constants {
	/**
	 * @deprecated
	 */
	const USES_BRIZY = 'brizy-use-brizy';

	const BRIZY_ENABLED = 'brizy_enabled';
}
