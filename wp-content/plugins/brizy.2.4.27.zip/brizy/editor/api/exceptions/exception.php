<?php

class Brizy_Editor_API_Exceptions_Exception extends Exception {
}