<?php

class Brizy_Editor_Exception_NotBrizyPage extends Brizy_Editor_Exceptions_NotFound {
	protected $message = 'Invalid page';
}